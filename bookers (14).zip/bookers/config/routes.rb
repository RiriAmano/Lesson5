Rails.application.routes.draw do
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
resources :books
root :to => 'homes#top'
root :to => 'books#new'
root :to => 'books#create'
root :to => 'books#show'
root :to => 'books#edit'
root :to => 'books#update'
delete 'books/:id' => 'books#destroy', as: 'destroy_book'
end
